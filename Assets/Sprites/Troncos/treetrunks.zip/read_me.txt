Hi, I hope you like these assets. You can get more like this from my site www.gamedeveloperstudio.com
If you like them or use them why not consider supporting my site, the more support the more assets I can produce.

Thanks 

Robert Brooks